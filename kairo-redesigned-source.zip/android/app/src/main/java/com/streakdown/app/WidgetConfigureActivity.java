package com.streakdown.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

/** Branded goal picker shown when a Kairo home-screen widget is added. */
public class WidgetConfigureActivity extends Activity {
    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private final int ink = Color.rgb(35, 20, 67);
    private final int muted = Color.rgb(105, 86, 135);
    private final int violet = Color.rgb(109, 40, 217);
    private final int magenta = Color.rgb(192, 38, 211);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        getWindow().setStatusBarColor(Color.rgb(246, 240, 255));
        getWindow().setNavigationBarColor(Color.rgb(246, 240, 255));
        setResult(RESULT_CANCELED);
        appWidgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(24), dp(22), dp(20));
        page.setBackgroundColor(Color.rgb(246, 240, 255));

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(gradient(new int[]{Color.rgb(76, 29, 149), violet, magenta}, dp(24)));
        TextView brand = text("Kairo", 27, Color.WHITE, true);
        TextView tagline = text("Make Today Count.", 14, Color.rgb(237, 224, 255), false);
        tagline.setPadding(0, dp(5), 0, 0);
        hero.addView(brand); hero.addView(tagline);
        page.addView(hero, new LinearLayout.LayoutParams(-1, -2));

        TextView heading = text("Choose a goal", 22, ink, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2); hp.topMargin = dp(24);
        page.addView(heading, hp);
        TextView sub = text("Your widget will keep your streak and countdown close at hand.", 14, muted, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(6); sp.bottomMargin = dp(16);
        page.addView(sub, sp);

        ScrollView scroll = new ScrollView(this);
        LinearLayout choices = new LinearLayout(this); choices.setOrientation(LinearLayout.VERTICAL);
        JSONArray goals = WidgetStore.getGoals(this);
        if (goals.length() == 0) {
            TextView empty = text("No goals yet", 18, ink, true);
            choices.addView(empty);
            TextView explanation = text("Create your first goal in Kairo, then add a widget to track it here. Kairo never adds sample goals automatically.", 14, muted, false);
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2); ep.topMargin = dp(8);
            choices.addView(explanation, ep);
            Button open = actionButton("Open Kairo", true);
            LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, dp(52)); op.topMargin = dp(18);
            choices.addView(open, op);
            open.setOnClickListener(v -> { Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName()); if (launch != null) startActivity(launch); finish(); });
        } else {
            for (int i = 0; i < goals.length(); i++) {
                JSONObject goal = goals.optJSONObject(i); if (goal == null) continue;
                final String id = goal.optString("id");
                String name = goal.optString("title", "Untitled goal");
                Button choice = actionButton(name + "   ›", false);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(58)); cp.bottomMargin = dp(10);
                choices.addView(choice, cp);
                choice.setOnClickListener(v -> configure(id));
            }
        }
        scroll.addView(choices);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1f); scrollParams.topMargin = dp(4);
        page.addView(scroll, scrollParams);
        setContentView(page);
    }

    private void configure(String goalId) {
        WidgetStore.setGoalForWidget(this, appWidgetId, goalId);
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        android.appwidget.AppWidgetProviderInfo info = manager.getAppWidgetInfo(appWidgetId);
        if (info != null && info.provider.getClassName().contains("LargeWidgetProvider")) LargeWidgetProvider.updateOne(this, manager, appWidgetId);
        else CompactWidgetProvider.updateOne(this, manager, appWidgetId);
        Intent result = new Intent(); result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_OK, result); finish();
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this); view.setText(value); view.setTextSize(size); view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }
    private Button actionButton(String value, boolean primary) {
        Button button = new Button(this); button.setText(value); button.setTextSize(15); button.setAllCaps(false); button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(primary ? Color.WHITE : ink);
        button.setPadding(dp(16), 0, dp(16), 0);
        button.setBackground(primary ? gradient(new int[]{violet, magenta}, dp(16)) : solid(Color.WHITE, dp(16), Color.rgb(222, 207, 248)));
        return button;
    }
    private GradientDrawable gradient(int[] colors, int radius) { GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors); d.setCornerRadius(radius); return d; }
    private GradientDrawable solid(int color, int radius, int stroke) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); d.setStroke(dp(1), stroke); return d; }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
