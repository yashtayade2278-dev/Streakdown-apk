package com.streakdown.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

final class WidgetViews {
    static final String ACTION_CHECK_IN = "com.streakdown.app.WIDGET_CHECK_IN";
    static RemoteViews create(Context c, int widgetId, boolean large) {
        RemoteViews v = new RemoteViews(c.getPackageName(), large ? R.layout.widget_large_native : R.layout.widget_compact_native);
        String goalId = WidgetStore.goalIdForWidget(c, widgetId);
        JSONObject g = WidgetStore.findGoal(c, goalId);
        if (g == null) {
            v.setTextViewText(R.id.widget_title, "Kairo");
            v.setTextViewText(R.id.widget_streak, "Open app to choose a goal");
            v.setTextViewText(R.id.widget_countdown, "Add a goal, then configure this widget");
            v.setTextViewText(R.id.widget_checkin, "Open app");
            Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            if (open != null) { PendingIntent launch = PendingIntent.getActivity(c, widgetId + 20000, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE); v.setOnClickPendingIntent(R.id.widget_root, launch); v.setOnClickPendingIntent(R.id.widget_title, launch); v.setOnClickPendingIntent(R.id.widget_streak, launch); v.setOnClickPendingIntent(R.id.widget_countdown, launch); v.setOnClickPendingIntent(R.id.widget_checkin, launch); }
            return v;
        }
        String title = g.optString("title", "Untitled goal");
        int streak = WidgetStore.activeStreak(g);
        String today = WidgetStore.today(); boolean checked = false;
        org.json.JSONArray arr=g.optJSONArray("checkIns"); if(arr!=null) for(int i=0;i<arr.length();i++) if(today.equals(arr.optString(i))) checked=true;
        int days=0; String target=g.optString("targetDate", today);
        try {
            java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US); fmt.setLenient(false);
            Calendar a=Calendar.getInstance(), b=Calendar.getInstance(); a.setTime(fmt.parse(today)); b.setTime(fmt.parse(target));
            days=(int)((b.getTimeInMillis()-a.getTimeInMillis())/86400000L);
        } catch(Exception ignored) {}
        v.setTextViewText(R.id.widget_title, title);
        v.setTextViewText(R.id.widget_streak, "🔥 " + streak + " day" + (streak==1?"":"s"));
        v.setTextViewText(R.id.widget_countdown, days > 0 ? days + " days remaining" : "Target date reached");
        v.setTextViewText(R.id.widget_checkin, checked ? "Checked in today ✓" : "Check in");
        v.setBoolean(R.id.widget_checkin, "setEnabled", !checked);
        Intent check = new Intent(c, WidgetCheckInReceiver.class); check.setAction(ACTION_CHECK_IN); check.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId); check.putExtra("goal_id", goalId);
        v.setOnClickPendingIntent(R.id.widget_checkin, PendingIntent.getBroadcast(c, widgetId, check, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if(open!=null) { PendingIntent launch = PendingIntent.getActivity(c,widgetId+10000,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); v.setOnClickPendingIntent(R.id.widget_root,launch); v.setOnClickPendingIntent(R.id.widget_title,launch); v.setOnClickPendingIntent(R.id.widget_streak,launch); v.setOnClickPendingIntent(R.id.widget_countdown,launch); }
        return v;
    }
    static void update(Context c, AppWidgetManager m, int[] ids, boolean large) { for(int id:ids) m.updateAppWidget(id,create(c,id,large)); }
    static void refresh(Context c, Class<?> provider, boolean large) { AppWidgetManager m=AppWidgetManager.getInstance(c); int[] ids=m.getAppWidgetIds(new ComponentName(c,provider)); update(c,m,ids,large); }
}
