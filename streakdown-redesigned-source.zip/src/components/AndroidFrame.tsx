import React from 'react';

interface AndroidFrameProps { children: React.ReactNode; }

/** The real Android device already supplies its own status and navigation bars. */
export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children }) => (
  <div className="min-h-screen w-full bg-indigo-50 text-slate-900 font-sans selection:bg-fuchsia-500 selection:text-white">
    <div className="min-h-screen w-full overflow-x-hidden">{children}</div>
  </div>
);
