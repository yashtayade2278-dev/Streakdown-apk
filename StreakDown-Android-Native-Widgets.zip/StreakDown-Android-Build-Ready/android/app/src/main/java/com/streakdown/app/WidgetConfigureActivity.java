package com.streakdown.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public class WidgetConfigureActivity extends Activity {
    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setResult(RESULT_CANCELED);
        appWidgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24); root.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this); title.setText("Choose a goal for this widget"); title.setTextSize(20); title.setPadding(0,0,0,18); root.addView(title);
        JSONArray goals = WidgetStore.getGoals(this);
        if (goals.length()==0) {
            TextView empty=new TextView(this); empty.setText("Open StreakDown and create a goal first, then add this widget again."); root.addView(empty);
            Button close=new Button(this); close.setText("Close"); close.setOnClickListener(v -> finish()); root.addView(close);
        }
        for (int i=0;i<goals.length();i++) {
            JSONObject g=goals.optJSONObject(i); if(g==null) continue;
            final String id=g.optString("id"); String name=g.optString("title","Untitled goal");
            Button b=new Button(this); b.setText(name); b.setOnClickListener(v -> {
                WidgetStore.setGoalForWidget(this, appWidgetId, id);
                AppWidgetManager manager=AppWidgetManager.getInstance(this);
                android.appwidget.AppWidgetProviderInfo info = manager.getAppWidgetInfo(appWidgetId);
                if (info != null && info.provider.getClassName().contains("LargeWidgetProvider")) LargeWidgetProvider.updateOne(this,manager,appWidgetId);
                else CompactWidgetProvider.updateOne(this,manager,appWidgetId);
                Intent result=new Intent(); result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,appWidgetId); setResult(RESULT_OK,result); finish();
            }); root.addView(b);
        }
        setContentView(root);
    }
}
